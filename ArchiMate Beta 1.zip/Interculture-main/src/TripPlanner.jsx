import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const TripPlanner = () => {
  return (
    <main className="flex-1 overflow-auto p-4">
      <Card>
        <CardHeader>
          <CardTitle>Upcoming Trip: Tokyo</CardTitle>
          <CardDescription>May 15 - May 22, 2023</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold">Itinerary</h3>
              <ul className="list-disc pl-5 space-y-2">
                <li>May 15: Arrival, Hotel Check-in</li>
                <li>May 16: Meeting with Tanaka Corp (10:00 AM)</li>
                <li>May 17: Site Visit to Yokohama Factory</li>
                <li>May 18-19: Tokyo Tech Conference</li>
                <li>May 20: Free Day (Cultural Activities)</li>
                <li>May 21: Final Negotiations with Tanaka Corp</li>
                <li>May 22: Departure</li>
              </ul>
            </div>
            <Button>Add to Calendar</Button>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}

export default TripPlanner;
