import React, { useState } from 'react'
import {
  Bell,
  Calendar,
  ChevronRight,
  ClipboardList,
  DollarSign,
  FileText,
  Home,
  Layers,
  MessageSquare,
  PieChart,
  Users,
  Globe,
  Briefcase,
  Settings,
} from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"

// Dashboard component definition
const Dashboard = () => {
  const [activeTab, setActiveTab] = useState("dashboard")

  // Dummy data for the dashboard cards
  const dashboardItems = [
    { title: "Upcoming Trips", value: "3", icon: Calendar },
    { title: "Cultural Insights", value: "24", icon: Globe },
    { title: "Language Proficiency", value: "68%", icon: MessageSquare },
    { title: "Business Meetings", value: "12", icon: Briefcase },
  ]

  return (
    <div className="space-y-4">
      {/* Render dashboard content based on the activeTab */}
      {activeTab === "dashboard" && (
        <div className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {dashboardItems.map(({ title, value, icon: Icon }) => (
              <Card key={title}>
                <CardHeader>
                  <div className="flex justify-between">
                    <CardTitle>{title}</CardTitle>
                    <Icon className="h-6 w-6 text-muted-foreground" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{value}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Additional Tab Content Logic Can Go Here */}
    </div>
  )
}

export default Dashboard


// import React, { useState } from 'react'
// import { Bell, Briefcase, Globe, Users, Calendar, MessageSquare, PieChart, Settings, User, ChevronRight, Search } from 'lucide-react'
// import { Button } from "@/components/ui/button"
// import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
// import { Input } from "@/components/ui/input"
// import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
// import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
// import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
// import { Progress } from "@/components/ui/progress"




// export default function Dashboard() {
//   const [activeTab, setActiveTab] = useState("dashboard")



//   const menuItems = [
//     { icon: Globe, label: "Dashboard", component:'./src/Dashboard.jsx' }, ]

//     return (
//       <div className="flex h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white">
//         {/* Sidebar */}
//         <aside className="w-64 border-r border-gray-700 bg-gray-900">
//           <div className="flex h-14 items-center border-b border-gray-700 px-4">
//             <Globe className="h-6 w-6 text-blue-400" />
//             <span className="ml-2 font-semibold text-xl">BCEP</span>
//           </div>
//           <nav className="space-y-1 p-4">
//             {menuItems.map(({ icon: Icon, label }) => (
//               <Button
//                 key={label}
//                 variant={activeTab === label.toLowerCase() ? "secondary" : "ghost"}
//                 className="w-full justify-start text-left font-medium"
//                 onClick={() => setActiveTab(label.toLowerCase())}
//               >
//                 <Icon className="mr-2 h-4 w-4" />
//                 {label}
//                 {activeTab === label.toLowerCase() && <ChevronRight className="ml-auto h-4 w-4" />}
//               </Button>
//             ))}
//           </nav>
//         </aside>

//     {/* constant header 
//      */}
//     <main className="flex-1 overflow-auto">
//       <header className="flex h-14 items-center justify-between border-b border-gray-700 px-6">
//         <h1 className="text-xl font-semibold">AI Business Culture Experience Protocol</h1>
//         <div className="flex items-center space-x-4">
//           <Button variant="outline" size="icon">
//             <Bell className="h-4 w-4" />
//           </Button>
//           <Avatar>
//             <AvatarImage src="https://github.com/shadcn.png" />
//             <AvatarFallback>JD</AvatarFallback>
//           </Avatar>
//         </div>
//       </header>







//       {/* LETS SEE 
//  */}
      
//       <div className="p-6">
//         <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
//           <TabsList className="grid w-full grid-cols-4 lg:grid-cols-7">
//             {menuItems.map(({ label }) => (
//               <TabsTrigger key={label} value={label.toLowerCase()}>
//                 {label}
//               </TabsTrigger>
//             ))}
//           </TabsList>


// <TabsContent value="dashboard" className="space-y-6">
//   <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
//     {[
//       { title: "Upcoming Trips", value: "3", icon: Calendar },
//       { title: "Cultural Insights", value: "24", icon: Globe },
//       { title: "Language Proficiency", value: "68%", icon: MessageSquare },
//       { title: "Business Meetings", value: "12", icon: Briefcase },
//     ].map(({ title, value, icon: Icon }) => (
//       <Card key={title}>
//         <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
//           <CardTitle className="text-sm font-medium">{title}</CardTitle>
//           <Icon className="h-4 w-4 text-muted-foreground" />
//         </CardHeader>
//         <CardContent>
//           <div className="text-2xl font-bold">{value}</div>
//         </CardContent>
//       </Card>
//     ))}
//   </div>
//   <Card>
//     <CardHeader>
//       <CardTitle>Next Trip: Tokyo, Japan</CardTitle>
//       <CardDescription>Departing in 5 days</CardDescription>
//     </CardHeader>
//     <CardContent>
//       <div className="space-y-4">
//         <div className="flex justify-between items-center">
//           <span>Cultural Preparation</span>
//           <Progress value={75} className="w-1/2" />
//         </div>
//         <div className="flex justify-between items-center">
//           <span>Language Readiness</span>
//           <Progress value={60} className="w-1/2" />
//         </div>
//         <div className="flex justify-between items-center">
//           <span>Business Etiquette</span>
//           <Progress value={80} className="w-1/2" />
//         </div>
//       </div>
//     </CardContent>
//   </Card>
// </TabsContent>


// </Tabs>
//         </div>
//       </main>
//     </div>
//   )
// }


