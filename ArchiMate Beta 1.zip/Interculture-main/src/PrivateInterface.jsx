import React, { useState } from 'react'


export default function StudioDiBerardino() {
  const [activeTab, setActiveTab] = useState("dashboard")

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <aside className="w-64 border-r bg-muted/30">
        <div className="flex h-14 items-center border-b px-4">
          <Layers className="h-6 w-6 text-primary" />
          <span className="ml-2 font-semibold">Studio DiBerardino</span>
        </div>
        <nav className="space-y-1 p-2">
          {menuItems.map(({ icon: Icon, label }) => (
            <Button
              key={label}
              variant={activeTab === label.toLowerCase() ? "secondary" : "ghost"}
              className="w-full justify-start"
              onClick={() => setActiveTab(label.toLowerCase())}
            >
              <Icon className="mr-2 h-4 w-4" />
              {label}
              {activeTab === label.toLowerCase() && <ChevronRight className="ml-auto h-4 w-4" />}
            </Button>
          ))}
        </nav>
      </aside>
