import React, { useState } from 'react';
import { X, Check, Building2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { supabase } from '@/supabase'; // Import the Supabase client

const CompanyInfoModal = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState("company-info");
  const [savedStatus, setSavedStatus] = useState(false);
  const [selectedCompanyProfile, setSelectedCompanyProfile] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    website: '',
    companyType: '',
    businessModel: '',
    developmentStage: '',
    description: '',
    currentMarkets: '',
    targetCountry: '',
    targetRegions: '',
    integrationTimeline: '',
    businessGoals: '',
    marketEntryStrategy: '',
  });

  if (!isOpen) return null;

  const companySampleProfiles = [
    { id: 1, name: "Tech Corp Inc", industry: "technology", type: "corporation" },
    { id: 2, name: "Health Services LLC", industry: "healthcare", type: "llc" }
  ];

  const previousPlans = [
    {
      id: "pr-plan",
      name: "Puerto Rico Expansion",
      description: "Market entry strategy for San Juan region",
      date: "2024-03-15"
    },
    {
      id: "dr-plan",
      name: "Dominican Republic Growth",
      description: "Sosua market development plan",
      date: "2024-02-28"
    }
  ];

  const handleSave = async () => {
    setSavedStatus(true);
  
    try {
      // Insert the company data into the Supabase table
      const { data, error } = await supabase.from('company_info').insert([
        {
          name: formData.name,
          website: formData.website,
          created_at: new Date().toISOString(), // Set created_at to current date and time
          company_type: formData.companyType,
          business_model: formData.businessModel,
          development_stage: formData.developmentStage,
          description: formData.description,
          current_markets: formData.currentMarkets,
          target_country: formData.targetCountry,
          target_regions: formData.targetRegions,
          integration_timeline: formData.integrationTimeline,
          business_goals: formData.businessGoals,
          market_entry_strategy: formData.marketEntryStrategy,
          
        },
      ]);
  
      // Check for errors in the insertion
      if (error) {
        console.error('Error saving company info:', error);
        setSavedStatus(false); // Indicate that the save was unsuccessful
      } else {
        console.log('Company info saved successfully:', data); // `data` may be null here
        setSavedStatus(true); // Indicate that the save was successful
      }
    } catch (error) {
      console.error('Error saving company info:', error);
      setSavedStatus(false); // Indicate that the save was unsuccessful
    }
  
    // Reset the active tab and saved status after a delay
    setTimeout(() => {
      setActiveTab("location-goals");
      setSavedStatus(false);
    }, 1500);
  };
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const loadCompanyProfile = (profile) => {
    setSelectedCompanyProfile(profile);
    // Populate the form fields with the profile data
    setFormData({
      name: profile.name,
      website: '',
      companyType: profile.type,
      businessModel: '',
      developmentStage: '',
      description: '',
      currentMarkets: '',
      targetCountry: '',
      targetRegions: '', // Change to targetRegion for single selection
      integrationTimeline: '',
      businessGoals: '',
      marketEntryStrategy: '', // Change to single selection
    });
  };
  

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50">
      <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose}></div>
      <div className="bg-white rounded-lg shadow-lg z-10 w-full max-w-4xl max-h-[90vh] overflow-y-auto p-6">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Business Profile & Integration Goals</h2>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Company Profile Selection */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-3">Load Existing Company Profile</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {companySampleProfiles.map((profile) => (
              <Card 
                key={profile.id}
                className={`cursor-pointer transition-all ${
                  selectedCompanyProfile?.id === profile.id 
                    ? 'ring-2 ring-blue-500' 
                    : 'hover:shadow-md'
                }`}
                onClick={() => loadCompanyProfile(profile)}
              >
                <CardHeader className="p-4">
                  <div className="flex items-center space-x-2">
                    <Building2 className="h-5 w-5 text-gray-500" />
                    <h4 className="font-medium">{profile.name}</h4>
                  </div>
                </CardHeader>
                <CardContent className="p-4 pt-0 text-sm text-gray-600">
                  <p>Industry: {profile.industry}</p>
                  <p>Type: {profile.type}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Tabs */}
        <div className="mb-6">
          <div className="flex border-b">
            <button
              className={`px-4 py-2 ${
                activeTab === "company-info"
                  ? "border-b-2 border-blue-500 text-blue-500"
                  : "text-gray-500"
              }`}
              onClick={() => setActiveTab("company-info")}
            >
              Company Information
            </button>
            <button
              className={`px-4 py-2 ${
                activeTab === "location-goals"
                  ? "border-b-2 border-blue-500 text-blue-500"
                  : "text-gray-500"
              }`}
              onClick={() => setActiveTab("location-goals")}
            >
              Location Goals
            </button>
          </div>
        </div>

        {/* Content */}
        {activeTab === "company-info" ? (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Company Name
                </label>
                <input
                  type="text"
                  className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter company name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                />
              </div>
              
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Website
                </label>
                <input
                  type="text"
                  className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="www.example.com"
                  name="website"
                  value={formData.website}
                  onChange={handleInputChange}
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Industries
                </label>
                <select className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  name="industry"
                  value={formData.industry}
                  onChange={handleInputChange}
                >
                  <option value="">Select industry</option>
                  <option value="technology">Technology</option>
                  <option value="manufacturing">Manufacturing</option>
                  <option value="retail">Retail</option>
                  <option value="healthcare">Healthcare</option>
                  <option value="financial">Financial Services</option>
                  <option value="education">Education</option>
                  <option value="hospitality">Hospitality</option>
                </select>
              </div>


              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Business Model
                </label>
                <select className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  name="businessModel"
                  value={formData.businessModel}
                  onChange={handleInputChange}
                >
                  <option value="">Select model</option>
                  <option value="b2b">B2B</option>
                  <option value="b2c">B2C</option>
                  <option value="b2b2c">B2B2C</option>
                  <option value="d2c">D2C</option>
                  <option value="marketplace">Marketplace</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Company Type
                </label>
                <select className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  name="companyType"
                  value={formData.companyType}
                  onChange={handleInputChange}
                >
                  <option value="">Select type</option>
                  <option value="corporation">Corporation</option>
                  <option value="llc">LLC</option>
                  <option value="partnership">Partnership</option>
                  <option value="sole-proprietorship">Sole Proprietorship</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Development Stage
                </label>
                <select className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  name="developmentStage"
                  value={formData.developmentStage}
                  onChange={handleInputChange}
                >
                  <option value="">Select stage</option>
                  <option value="seed">Seed</option>
                  <option value="early">Early Stage</option>
                  <option value="growth">Growth Stage</option>
                  <option value="mature">Mature</option>
                  <option value="enterprise">Enterprise</option>
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">
                Company Description
              </label>
              <textarea
                className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 h-32"
                placeholder="Describe your company's main products/services..."
                name="description"
                value={formData.description}
                onChange={handleInputChange}
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">
                Current Markets
              </label>
              <textarea
                className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 h-24"
                placeholder="List the geographical markets where your company currently operates..."
                name="currentMarkets"
                value={formData.currentMarkets}
                onChange={handleInputChange}
              />
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-3">Previous Integration Plans</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {previousPlans.map((plan) => (
                  <Card key={plan.id} className="cursor-pointer hover:shadow-md">
                    <CardHeader className="p-4">
                      <h4 className="font-medium">{plan.name}</h4>
                      <p className="text-sm text-gray-500">{plan.date}</p>
                    </CardHeader>
                    <CardContent className="p-4 pt-0">
                      <p className="text-sm text-gray-600">{plan.description}</p>
                      <Button 
                        variant="outline"
                        className="mt-3"
                        onClick={() => {
                          // Handle loading plan
                        }}
                      >
                        Load Plan
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Target Country
                </label>
                <select className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  name="targetCountry"
                  value={formData.targetCountry}
                  onChange={handleInputChange}
                >
                  <option value="">Select country</option>
                  <option value="puerto-rico">Puerto Rico</option>
                  <option value="dominican-republic">Dominican Republic</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Target Regions (Select multiple)
                </label>
                <select multiple className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 h-24"
                  name="targetRegions"
                  value={formData.targetRegions}
                  onChange={handleInputChange}
                >
                  <option value="sosua">Sosua</option>
                  <option value="san-juan">San Juan</option>
                  <option value="punta-cana">Punta Cana</option>
                  <option value="santiago">Santiago</option>
                  <option value="mayaguez">Mayagüez</option>
                  <option value="ponce">Ponce</option>
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">
                Integration Timeline
              </label>
              <select className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                name="integrationTimeline"
                value={formData.integrationTimeline}
                onChange={handleInputChange}
              >
                <option value="">Select timeline</option>
                <option value="0-6">0-6 months</option>
                <option value="6-12">6-12 months</option>
                <option value="12-24">1-2 years</option>
                <option value="24+">2+ years</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">
                Business Goals
              </label>
              <textarea
                className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 h-32"
                placeholder="Describe your specific goals for this location..."
                name="businessGoals"
                value={formData.businessGoals}
                onChange={handleInputChange}
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">
                Market Entry Strategy
              </label>
              <select multiple className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 h-24"
                name="marketEntryStrategy"
                value={formData.marketEntryStrategy}
                onChange={handleInputChange}
              >
                <option value="direct">Direct Market Entry</option>
                <option value="partnership">Local Partnership</option>
                <option value="acquisition">Acquisition</option>
                <option value="franchise">Franchise Model</option>
                <option value="distributor">Distributor Network</option>
                <option value="joint-venture">Joint Venture</option>
              </select>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="flex justify-end items-center space-x-2 mt-6">
          <div className="flex-grow">
            {savedStatus && (
              <span className="flex items-center text-green-600">
                <Check className="h-5 w-5 mr-1" />
                Saved successfully
              </span>
            )}
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
          >
            Close
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
          >
            Save Profile
          </button>
        </div>
      </div>
    </div>
  );
};

export default CompanyInfoModal;