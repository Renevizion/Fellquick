import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const Analytics = () => {
  return (
    <main className="flex-1 overflow-auto p-4">
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Cultural Adaptation Progress</CardTitle>
          <CardDescription>Your improvement over time</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[200px] w-full bg-muted rounded-md flex items-center justify-center">
            [Progress Chart Placeholder]
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Performance by Region</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              <li className="flex justify-between items-center">
                <span className="font-medium">North America</span>
                <div className="flex items-center">
                  <span className="mr-2">85%</span>
                  <div className="text-green-500 h-4 w-4">↗</div>
                </div>
              </li>
              <li className="flex justify-between items-center">
                <span className="font-medium">Europe</span>
                <div className="flex items-center">
                  <span className="mr-2">72%</span>
                  <div className="text-green-500 h-4 w-4">↗</div>
                </div>
              </li>
              <li className="flex justify-between items-center">
                <span className="font-medium">Asia Pacific</span>
                <div className="flex items-center">
                  <span className="mr-2">68%</span>
                  <div className="text-red-500 h-4 w-4">↘</div>
                </div>
              </li>
              <li className="flex justify-between items-center">
                <span className="font-medium">Latin America</span>
                <div className="flex items-center">
                  <span className="mr-2">79%</span>
                  <div className="text-green-500 h-4 w-4">↗</div>
                </div>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Trend Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[200px] w-full bg-muted flex items-center justify-center rounded-md">
              [Trend Chart Placeholder]
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  );
};

export default Analytics;