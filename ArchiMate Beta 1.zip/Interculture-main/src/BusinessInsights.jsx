import React, { useState } from 'react';
import {
  Building,
  Globe,
  Calendar,
  Target,
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ContentAgent from '@/Agentforce/ContentAgent';

const BusinessInsights = () => {
  const [companyData, setCompanyData] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);
  const [loading, setLoading] = useState(false);
  
  const { fetchAndAnalyzeData } = ContentAgent({
    onDataFetched: (data) => {
      setCompanyData(data);
    },
    onError: (message) => {
      setErrorMessage(message);
    },
    onLoading: (isLoading) => {
      setLoading(isLoading);
    }
  });

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <Button 
          onClick={fetchAndAnalyzeData} 
          disabled={loading}
          className="mb-6"
        >
          {loading ? 'Analyzing...' : 'Analyze Company Data'}
        </Button>
        {errorMessage && (
          <div className="text-red-500 mb-6 p-2 bg-red-50 rounded">
            {errorMessage}
          </div>
        )}
      </div>

      <Tabs defaultValue="business-insights">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="business-insights">Overview</TabsTrigger>
          <TabsTrigger value="markets">Markets</TabsTrigger>
          <TabsTrigger value="goals">Goals</TabsTrigger>
          <TabsTrigger value="timeline">Timeline</TabsTrigger>
        </TabsList>

        <TabsContent value="business-insights">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building className="h-5 w-5" />
                Company Profile
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center p-4 bg-gray-50">
                  Analyzing company data...
                </div>
              ) : companyData ? (
                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold mb-2">Company Name</h3>
                    <p>{companyData.name || "Not specified"}</p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Description</h3>
                    <p>{companyData.description || "No description available"}</p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">AI Analysis</h3>
                    <div className="bg-gray-50 p-4 rounded">
                      {companyData.aiAnalysis || "No analysis available."}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center text-gray-500 p-4">
                  Click 'Analyze Company Data' to start
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="markets">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5" />
                Market Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center p-4 bg-gray-50">
                  Analyzing market data...
                </div>
              ) : companyData?.marketAnalysis ? (
                <div className="bg-gray-50 p-4 rounded">
                  {companyData.marketAnalysis}
                </div>
              ) : (
                <div className="text-center text-gray-500">
                  No market analysis available
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="goals">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Business Goals
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center p-4 bg-gray-50">
                  Analyzing goals...
                </div>
              ) : companyData?.businessGoals ? (
                <div className="bg-gray-50 p-4 rounded">
                  {companyData.businessGoals}
                </div>
              ) : (
                <div className="text-center text-gray-500">
                  No business goals available
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="timeline">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Integration Timeline 
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center p-4 bg-gray-50">
                  Analyzing timeline...
                </div>
              ) : companyData?.timeline ? (
                <div className="bg-gray-50 p-4 rounded">
                  {companyData.timeline}
                </div>
              ) : (
                <div className="text-center text-gray-500">
                  No timeline information available
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default BusinessInsights;