import React, { useState, useEffect } from 'react'
import { supabase } from './supabase'
import {
  Bell,
  Calendar,
  ChevronRight,
  ClipboardList,
  DollarSign,
  FileText,
  Home,
  Layers,
  MessageSquare,
  PieChart,
  Users,
  Globe,
  Briefcase,
  Settings,
  Plus,
} from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import Dashboard from "./Dashboard"
import BusinessInsights from "./BusinessInsights"
import CulturalEtiquette from "./CulturalEtiquette"
import TripPlanner from "./TripPlanner"
import LanguageAssistant from './LanguageAssistant'
import Analytics from './Analytics'
import UserSettings from './UserSettings'
import AuthPage from './AuthPage'
import CompanyInfoModal from './CompanyInfoModal'

export default function StudioDiBerardino() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    // Check active session when component mounts
    checkUser();

    // Set up listener for auth state changes
    const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_IN') {
        setUser(session?.user ?? null);
      } else if (event === 'SIGNED_OUT') {
        setUser(null);
      }
    });

    return () => {
      // Clean up listener on component unmount
      if (authListener?.unsubscribe) {
        authListener.unsubscribe();
      }
    };
  }, []);

  const checkUser = async () => {
    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      if (error) throw error;
      setUser(session?.user ?? null);
    } catch (error) {
      console.error('Error checking auth status:', error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      setUser(null);
    } catch (error) {
      console.error('Error logging out:', error.message);
    }
  };

  const menuItems = [
    { icon: Globe, label: "Dashboard" },
    { icon: Briefcase, label: "Business Insights" },
    { icon: Users, label: "Cultural Etiquette" },
    { icon: Calendar, label: "Trip Planner" },
    { icon: MessageSquare, label: "Language Assistant" },
    { icon: PieChart, label: "Analytics" },
    { icon: Settings, label: "Settings" },
  ];

  if (loading) {
    return <div className="flex h-screen items-center justify-center">Loading...</div>;
  }

  if (!user) {
    return <AuthPage />;
  }

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <aside className="w-64 border-r bg-muted/30">
        <div className="flex h-14 items-center border-b px-4">
          <Layers className="h-6 w-6 text-primary" />
          <span className="ml-2 font-semibold">Interlink</span>
        </div>
        <nav className="space-y-1 p-2">
          {menuItems.map(({ icon: Icon, label }) => (
            <Button
              key={label}
              variant={activeTab === label.toLowerCase() ? "secondary" : "ghost"}
              className="w-full justify-start"
              onClick={() => setActiveTab(label.toLowerCase())}
            >
              <Icon className="mr-2 h-4 w-4" />
              {label}
              {activeTab === label.toLowerCase() && <ChevronRight className="ml-auto h-4 w-4" />}
            </Button>
          ))}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <header className="flex h-14 items-center justify-between border-b px-4">
          <h1 className="text-lg font-semibold">Global Workspace</h1>
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setIsModalOpen(true)}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Plus className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon">
              <Bell className="h-4 w-4" />
            </Button>
            <Button>{user.email}</Button>
            <Button 
              onClick={handleLogout}
              variant="outline"
            >
              Logout
            </Button>
          </div>
        </header>

        <div className="p-6 space-y-4">
          <div className="flex space-x-2">
            {menuItems.map(({ label }) => (
              <Button
                key={label}
                variant={activeTab === label.toLowerCase() ? "secondary" : "ghost"}
                onClick={() => setActiveTab(label.toLowerCase())}
              >
                {label}
              </Button>
            ))}
          </div>

          {/* Tab Content */}
          {activeTab === "dashboard" && <Dashboard />}
          {activeTab === "cultural etiquette" && <CulturalEtiquette />}
          {activeTab === "business insights" && <BusinessInsights />}
          {activeTab === "language assistant" && <LanguageAssistant />}
          {activeTab === "trip planner" && <TripPlanner />}
          {activeTab === "analytics" && <Analytics />}
          {activeTab === "settings" && <UserSettings />}
        </div>

        {/* Company Info Modal */}
        <CompanyInfoModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
        />
      </main>
    </div>
  );
}