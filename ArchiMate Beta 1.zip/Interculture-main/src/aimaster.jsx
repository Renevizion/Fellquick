// // aimaster.jsx
// "use server"; // This indicates that the file should be treated as a server component
// import OpenAI from 'openai';

// // Initialize OpenAI with the correct API key from environment variables
// const openai = new OpenAI({
//   apiKey: import.meta.env.OPENAI_API_KEY, // Ensure this is set in your .env.local
//   dangerouslyAllowBrowser: true, // Allow browser usage if needed; only for testing purposes
//   organization: "org-xcZShFuRwhplR2jzeZtS3cIU", // Optional: your organization ID
// });

// export const getAiAnalysis = async (companyData) => {
//   try {
//     // Your logic to call the OpenAI API
//     const response = await openai.chat.completions.create({
//       model: 'gpt-4', // Use the correct model
//       messages: [
//         {
//           role: 'user',
//           content: `Analyze this company: ${JSON.stringify(companyData)}`,
//         },
//       ],
//     });

//     return response.choices[0].message.content; // Adjust based on your OpenAI API response structure
//   } catch (error) {
//     console.error('Error fetching AI analysis:', error);
//     throw new Error('Failed to get AI analysis'); // Handle error appropriately
//   }
// };
