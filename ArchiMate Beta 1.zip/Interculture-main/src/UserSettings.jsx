import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const Settings = () => {
  return (
    <main className="flex-1 overflow-auto p-4">
      <Card>
        <CardHeader>
          <CardTitle>Account Settings</CardTitle>
          <CardDescription>Manage your BCEP preferences</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span>Notification Preferences</span>
              <Button variant="outline">Configure</Button>
            </div>
            <div className="flex justify-between items-center">
              <span>Language Settings</span>
              <Button variant="outline">Change</Button>
            </div>
            <div className="flex justify-between items-center">
              <span>Data Privacy</span>
              <Button variant="outline">Review</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}

export default Settings;
