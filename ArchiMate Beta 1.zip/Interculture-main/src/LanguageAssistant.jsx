import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const LanguageAssistant = () => {
  return (
    <main className="flex-1 overflow-auto p-4">
      <Card>
        <CardHeader>
          <CardTitle>Japanese Phrase Book</CardTitle>
          <CardDescription>Essential business phrases</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span>Hajimemashite</span>
              <span className="text-muted-foreground">Nice to meet you</span>
            </div>
            <div className="flex justify-between items-center">
              <span>Yoroshiku onegaishimasu</span>
              <span className="text-muted-foreground">Please treat me favorably</span>
            </div>
            <div className="flex justify-between items-center">
              <span>Arigato gozaimasu</span>
              <span className="text-muted-foreground">Thank you very much</span>
            </div>
            <Button>Practice Pronunciation</Button>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}

export default LanguageAssistant;
