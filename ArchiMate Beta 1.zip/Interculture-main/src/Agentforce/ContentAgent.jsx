import { createClient } from '@supabase/supabase-js';
import OpenAI from 'openai';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || import.meta.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || import.meta.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
const OPENAI_API_KEY = import.meta.env.VITE_OPENAI_API_KEY || import.meta.env.NEXT_PUBLIC_OPENAI_API_KEY;

const supabase = SUPABASE_URL && SUPABASE_ANON_KEY 
  ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
  : null;

const openai = OPENAI_API_KEY
  ? new OpenAI({ apiKey: OPENAI_API_KEY, dangerouslyAllowBrowser: true  })
  : null;

const ContentAgent = ({ onDataFetched, onError, onLoading }) => {
  const validateEnvironment = () => {
    const missing = [];
    if (!SUPABASE_URL) missing.push('Supabase URL');
    if (!SUPABASE_ANON_KEY) missing.push('Supabase Anon Key');
    if (!OPENAI_API_KEY) missing.push('OpenAI API Key');
    
    if (missing.length > 0) {
      throw new Error(`Missing environment variables: ${missing.join(', ')}`);
    }
  };

  const extractSection = (content, sectionName) => {
    const sectionRegex = new RegExp(`${sectionName}[\\s\\S]*?(?=\\n\\n[A-Z]|$)`);
    const match = content.match(sectionRegex);
    return match ? match[0].replace(`${sectionName}\n`, '').trim() : '';
  };

  const structureCompanyData = (rawData, aiAnalysis) => {
    return {
      ...rawData,
      aiAnalysis,
      marketAnalysis: extractSection(aiAnalysis, 'LOCATION ANALYSIS'),
      businessGoals: extractSection(aiAnalysis, 'EXPANSION STRATEGY'),
      timeline: extractSection(aiAnalysis, 'ACTION PLAN')
    };
  };

  const fetchAndAnalyzeData = async () => {
    try {
      onLoading?.(true);
      validateEnvironment();

      const { data: companyData, error: supabaseError } = await supabase
        .from('company_info')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(1);

      if (supabaseError) throw new Error(`Database error: ${supabaseError.message}`);
      if (!companyData?.length) throw new Error('No company data found');

      const completion = await openai.chat.completions.create({
        messages: [
          {
            role: "system",
            content: `You are a location intelligence specialist focusing on Dominican Republic and New York expansion. 
            Provide SPECIFIC insights in this exact format, focusing on concrete details and numbers:

            LOCATION ANALYSIS
            • Dominican Republic Hotspots (name 3 specific cities/areas):
            - [City 1]: Why + Target demographic + Market size
            - [City 2]: Why + Target demographic + Market size
            - [City 3]: Why + Target demographic + Market size
            
            • New York Focus Areas (name 3 specific neighborhoods):
            - [Area 1]: Why + Foot traffic data + Income levels
            - [Area 2]: Why + Foot traffic data + Income levels
            - [Area 3]: Why + Foot traffic data + Income levels

            EXPANSION STRATEGY
            • Store Launch Sequence:
            1. First Location: [Exact area] + [Expected monthly revenue]
            2. Second Location: [Exact area] + [Expected monthly revenue]
            3. Third Location: [Exact area] + [Expected monthly revenue]
            
            • Required Local Partnerships:
            - Name 2 specific potential partners per location
            - List exact permit requirements per location
            - List exact staffing needs per location

            ACTION PLAN
            • Next 30 Days:
            1. [Specific action] - [Exact cost] - [Specific owner]
            2. [Specific action] - [Exact cost] - [Specific owner]
            3. [Specific action] - [Exact cost] - [Specific owner]
            
            • Next 60 Days:
            1. [Specific action] - [Exact cost] - [Specific owner]
            2. [Specific action] - [Exact cost] - [Specific owner]
            3. [Specific action] - [Exact cost] - [Specific owner]`
          },
          {
            role: "user",
            content: `Analyze this company data and provide specific geographical insights for Dominican Republic and New York expansion: ${JSON.stringify(companyData[0])}`
          }
        ],
        model: "gpt-4-turbo-preview",
        temperature: 0.2,
        max_tokens: 1500
      });

      const analysis = completion.choices[0].message.content;
      const structuredData = structureCompanyData(companyData[0], analysis);

      onDataFetched?.(structuredData);
    } catch (error) {
      console.error('Error in ContentAgent:', error);
      onError?.(error.message);
    } finally {
      onLoading?.(false);
    }
  };

  return { fetchAndAnalyzeData };
};

export default ContentAgent;