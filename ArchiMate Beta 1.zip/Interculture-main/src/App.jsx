import React, { useState, useEffect } from 'react';
import StudioDiBerardino from './StudioDiBerardino';
import AuthPage from './AuthPage';
import { supabase } from './supabase';

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing session on load
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  // Debug logging
  console.log('Auth State:', { user, loading });

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-background">
      {user ? (
        <StudioDiBerardino user={user} />
      ) : (
        <AuthPage />
      )}
    </div>
  );
}

export default App;