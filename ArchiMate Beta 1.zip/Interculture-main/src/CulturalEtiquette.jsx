import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { TabsContent } from "@/components/ui/tabs";

const CulturalEtiquette = () => {
  return (
    <TabsContent value="cultural etiquette" className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Etiquette Guide: Japan</CardTitle>
          <CardDescription>Essential dos and don'ts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold">Greetings</h3>
              <p>Bow slightly when greeting. The depth and duration of the bow can vary based on the status of the person you're greeting.</p>
            </div>
            <div>
              <h3 className="font-semibold">Dining</h3>
              <p>Don't stick your chopsticks upright in your rice. This resembles incense sticks at a funeral.</p>
            </div>
            <div>
              <h3 className="font-semibold">Gift Giving</h3>
              <p>Gifts are common in business. Avoid giving four or nine of anything, as these numbers are considered unlucky.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </TabsContent>
  );
};

export default CulturalEtiquette;
