import * as React from "react"
import { cn } from "@/lib/utils"

const Select = React.forwardRef(({ className, ...props }, ref) => (
  <select
    ref={ref}
    className={cn("block w-full border border-gray-300 rounded-md shadow-sm", className)}
    {...props}
  />
))
Select.displayName = "Select"

const SelectTrigger = React.forwardRef(({ className, ...props }, ref) => (
  <button
    ref={ref}
    className={cn("flex items-center justify-between px-4 py-2 bg-white border rounded-md", className)}
    {...props}
  />
))
SelectTrigger.displayName = "SelectTrigger"

const SelectValue = React.forwardRef(({ className, ...props }, ref) => (
  <span
    ref={ref}
    className={cn("truncate", className)}
    {...props}
  />
))
SelectValue.displayName = "SelectValue"

const SelectContent = React.forwardRef(({ className, ...props }, ref) => (
  <div ref={ref} className={cn("absolute mt-1 w-full bg-white border border-gray-300 rounded-md shadow-lg", className)} {...props} />
))
SelectContent.displayName = "SelectContent"

const SelectItem = React.forwardRef(({ className, ...props }, ref) => (
  <div ref={ref} className={cn("cursor-pointer p-2 hover:bg-gray-100", className)} {...props} />
))
SelectItem.displayName = "SelectItem"

export { Select, SelectTrigger, SelectValue, SelectContent, SelectItem }
