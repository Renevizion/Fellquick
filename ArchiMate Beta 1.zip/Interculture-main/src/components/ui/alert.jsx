// Alert.jsx
import React from 'react';
import Modal from '@/components/ui/Modal'; // Ensure this path is correct
import { Button } from '@/components/ui/button'; // Ensure this path is correct
import './Alert.css';

const Alert = ({ title, type = 'info', onClose, description }) => {
  return (
    <Modal isOpen={true} onClose={onClose} title={title}>
      <div className={`alert-content ${type}`}>
        <h2>{title}</h2>
        {description && <AlertDescription message={description} />}
        <Button onClick={onClose}>Close</Button>
      </div>
    </Modal>
  );
};

// AlertDescription Component
const AlertDescription = ({ message }) => {
  return <p>{message}</p>;
};

// Export both components
export { Alert, AlertDescription };
