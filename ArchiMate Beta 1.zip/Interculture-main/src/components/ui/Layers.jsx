import React from "react";

function Layers() {
  return (
    <div className="p-4 bg-gray-100 rounded-lg shadow">
      <h2 className="text-xl font-semibold mb-4">Layers Section</h2>
      <p>This is where you can manage the different layers in your design or project.</p>

      <ul className="mt-4 space-y-2">
        <li className="p-2 bg-white rounded shadow">Layer 1: Ground Floor</li>
        <li className="p-2 bg-white rounded shadow">Layer 2: First Floor</li>
        <li className="p-2 bg-white rounded shadow">Layer 3: Roof</li>
      </ul>
    </div>
  );
}

export default Layers;
